# Q13. Find the second-largest number in a list

numbers = list(map(float, input("Enter numbers separated by space: ").split()))

largest = None
second = None

for n in numbers:
    if largest is None or n > largest:
        if largest is not None:
            second = largest
        largest = n
    elif n != largest and (second is None or n > second):
        second = n

if second is None:
    print("There is no second-largest number (need at least two distinct values).")
else:
    print("Second largest number:", second)
