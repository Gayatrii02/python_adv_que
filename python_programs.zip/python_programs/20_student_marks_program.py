# Q20. Student marks program
# - accepts marks for 5 subjects
# - calculates total and percentage
# - assigns a grade
# - displays whether the student passed or failed

PASS_MARK = 35  # minimum marks required in each subject

marks = []
for i in range(1, 6):
    while True:
        try:
            m = float(input(f"Enter marks for subject {i} (0-100): "))
            if 0 <= m <= 100:
                marks.append(m)
                break
            print("  Marks must be between 0 and 100.")
        except ValueError:
            print("  Invalid input. Enter a number.")

total = sum(marks)
percentage = total / 5

if percentage >= 90:
    grade = "A+"
elif percentage >= 80:
    grade = "A"
elif percentage >= 70:
    grade = "B"
elif percentage >= 60:
    grade = "C"
elif percentage >= 50:
    grade = "D"
elif percentage >= 35:
    grade = "E"
else:
    grade = "F"

# Fail if any subject is below the pass mark
passed = all(m >= PASS_MARK for m in marks)

print("\n------ RESULT ------")
print("Marks      :", marks)
print(f"Total      : {total} / 500")
print(f"Percentage : {percentage:.2f}%")
print("Grade      :", grade)
print("Result     :", "PASS" if passed else "FAIL")
