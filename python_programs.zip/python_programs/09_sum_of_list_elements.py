# Q9. Find the sum of all elements in a list

numbers = list(map(float, input("Enter numbers separated by space: ").split()))

total = 0
for n in numbers:
    total += n

print("List:", numbers)
print("Sum of all elements:", total)
