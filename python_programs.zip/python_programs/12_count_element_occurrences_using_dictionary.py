# Q12. Count how many times each element appears in a list using a dictionary

items = input("Enter elements separated by space: ").split()

count = {}
for item in items:
    if item in count:
        count[item] += 1
    else:
        count[item] = 1

print("\nElement frequencies:")
for key, value in count.items():
    print(f"{key} -> {value}")
