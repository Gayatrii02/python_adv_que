# Q15. Function that accepts a list of numbers and returns only the even numbers

def get_even_numbers(numbers):
    evens = []
    for n in numbers:
        if n % 2 == 0:
            evens.append(n)
    return evens


nums = list(map(int, input("Enter numbers separated by space: ").split()))
print("Even numbers:", get_even_numbers(nums))
