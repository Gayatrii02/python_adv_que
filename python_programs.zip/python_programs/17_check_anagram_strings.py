# Q17. Check whether two strings are anagrams of each other

s1 = input("Enter first string : ")
s2 = input("Enter second string: ")

# ignore case and spaces
a = s1.replace(" ", "").lower()
b = s2.replace(" ", "").lower()


def char_count(s):
    d = {}
    for ch in s:
        d[ch] = d.get(ch, 0) + 1
    return d


if char_count(a) == char_count(b):
    print(f'"{s1}" and "{s2}" are anagrams')
else:
    print(f'"{s1}" and "{s2}" are NOT anagrams')
