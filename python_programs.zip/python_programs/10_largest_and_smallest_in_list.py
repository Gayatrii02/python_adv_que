# Q10. Find the largest and smallest element in a list without max() or min()

numbers = list(map(float, input("Enter numbers separated by space: ").split()))

if not numbers:
    print("The list is empty.")
else:
    largest = numbers[0]
    smallest = numbers[0]
    for n in numbers:
        if n > largest:
            largest = n
        if n < smallest:
            smallest = n

    print("Largest element :", largest)
    print("Smallest element:", smallest)
