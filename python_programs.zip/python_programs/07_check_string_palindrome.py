# Q7. Check whether a string is a palindrome

text = input("Enter a string: ")

# ignore case, spaces and punctuation
cleaned = "".join(ch.lower() for ch in text if ch.isalnum())

is_palindrome = True
left, right = 0, len(cleaned) - 1
while left < right:
    if cleaned[left] != cleaned[right]:
        is_palindrome = False
        break
    left += 1
    right -= 1

if is_palindrome:
    print(f'"{text}" is a palindrome')
else:
    print(f'"{text}" is NOT a palindrome')
