# Q16. Find the frequency of each character in a string

text = input("Enter a string: ")

freq = {}
for ch in text:
    freq[ch] = freq.get(ch, 0) + 1

print("\nCharacter frequencies:")
for ch, count in freq.items():
    shown = "' ' (space)" if ch == " " else f"'{ch}'"
    print(f"{shown} -> {count}")
