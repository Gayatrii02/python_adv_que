# Q14. Sort a list without using sort() or sorted()  (Bubble Sort)

numbers = list(map(float, input("Enter numbers separated by space: ").split()))
print("Original list:", numbers)

n = len(numbers)
for i in range(n - 1):
    for j in range(n - i - 1):
        if numbers[j] > numbers[j + 1]:
            numbers[j], numbers[j + 1] = numbers[j + 1], numbers[j]

print("Sorted list  :", numbers)
