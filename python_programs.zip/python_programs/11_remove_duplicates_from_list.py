# Q11. Remove duplicate elements from a list (order is preserved)

numbers = input("Enter elements separated by space: ").split()

unique = []
for item in numbers:
    if item not in unique:
        unique.append(item)

print("Original list      :", numbers)
print("List without duplicates:", unique)
