# Q18. Find all duplicate values in a list

items = input("Enter elements separated by space: ").split()

seen = []
duplicates = []

for item in items:
    if item in seen:
        if item not in duplicates:
            duplicates.append(item)
    else:
        seen.append(item)

print("List:", items)
if duplicates:
    print("Duplicate values:", duplicates)
else:
    print("No duplicate values found.")
