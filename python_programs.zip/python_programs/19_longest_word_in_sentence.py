# Q19. Take a sentence and find the longest word

sentence = input("Enter a sentence: ")

longest = ""
for word in sentence.split():
    word = word.strip(".,!?;:\"'()")
    if len(word) > len(longest):
        longest = word

if longest:
    print(f'Longest word: "{longest}" ({len(longest)} letters)')
else:
    print("No words found.")
